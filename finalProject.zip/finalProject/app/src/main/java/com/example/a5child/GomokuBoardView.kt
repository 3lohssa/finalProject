package com.example.a5child

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

class GomokuBoardView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    private val boardSize = 15
    private val boardBackground: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.board_background)
    private val blackPiece: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.black_piece)
    private val whitePiece: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.white_piece)
    private val paint = Paint().apply {
        color = Color.BLACK
        strokeWidth = 5f
        style = Paint.Style.STROKE
    }

    private val board = Array(boardSize) { IntArray(boardSize) }
    private var currentPlayer = 1

    private var cellSize: Float = 0f
    private var offsetX: Float = 0f
    private var offsetY: Float = 0f

    init {
        setBackgroundColor(Color.WHITE)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Calculate scale to fit the board in the view while maintaining aspect ratio
        val scale = minOf(width.toFloat() / boardBackground.width, height.toFloat() / boardBackground.height)

        // Calculate offsets to center the board
        offsetX = (width - boardBackground.width * scale) / 2
        offsetY = (height - boardBackground.height * scale) / 2

        // Calculate cell size based on scaled background image
        cellSize = (boardBackground.width * scale) / (boardSize - 1)

        // Set the matrix to scale and translate the board to center it
        val matrix = Matrix().apply {
            setScale(scale, scale)
            postTranslate(offsetX, offsetY)
        }

        // Draw the board background
        canvas.drawBitmap(boardBackground, matrix, null)

        // Draw the pieces
        for (i in 0 until boardSize) {
            for (j in 0 until boardSize) {
                if (board[i][j] != 0) {
                    val cx = offsetX + i * cellSize
                    val cy = offsetY + j * cellSize
                    val piece = if (board[i][j] == 1) blackPiece else whitePiece
                    val pieceSize = cellSize * 0.6f // Adjusted size
                    val left = cx - pieceSize / 2
                    val top = cy - pieceSize / 2
                    val right = cx + pieceSize / 2
                    val bottom = cy + pieceSize / 2
                    canvas.drawBitmap(piece, null, RectF(left, top, right, bottom), null)
                }
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            val x = event.x
            val y = event.y

            // Calculate the closest grid point
            val i = ((x - offsetX) / cellSize).toInt()
            val j = ((y - offsetY) / cellSize).toInt()

            if (i in 0 until boardSize && j in 0 until boardSize && board[i][j] == 0) {
                board[i][j] = currentPlayer
                currentPlayer = if (currentPlayer == 1) 2 else 1
                invalidate() // Redraw the view
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}
